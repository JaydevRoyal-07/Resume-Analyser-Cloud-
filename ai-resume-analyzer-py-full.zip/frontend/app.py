import streamlit as st
import requests
import os
from dotenv import load_dotenv

load_dotenv()
API_URL = os.getenv("API_URL", "http://localhost:8000/api")

st.set_page_config(page_title="AI Resume Analyzer (Python)", layout="wide")

if "token" not in st.session_state:
    st.session_state.token = None
if "user" not in st.session_state:
    st.session_state.user = None

st.title("AI-Powered Resume Analyzer (Python stack)")

def api_post(path, json=None, files=None):
    headers = {}
    if st.session_state.token:
        headers["Authorization"] = f"Bearer {st.session_state.token}"
    try:
        if files:
            r = requests.post(f"{API_URL}{path}", files=files, headers=headers, timeout=120)
        else:
            r = requests.post(f"{API_URL}{path}", json=json, headers=headers, timeout=30)
        return r
    except Exception as e:
        st.error("API request failed: " + str(e))
        return None

def api_get(path):
    headers = {}
    if st.session_state.token:
        headers["Authorization"] = f"Bearer {st.session_state.token}"
    try:
        r = requests.get(f"{API_URL}{path}", headers=headers, timeout=30)
        return r
    except Exception as e:
        st.error("API request failed: " + str(e))
        return None

if not st.session_state.token:
    with st.form("login_form"):
        st.subheader("Login / Register (for testing)")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        name = st.text_input("Name (for register)")
        col1, col2 = st.columns(2)
        with col1:
            login_btn = st.form_submit_button("Login")
        with col2:
            register_btn = st.form_submit_button("Register")
    if login_btn:
        r = api_post("/auth/login", json={"email": email, "password": password})
        if r and r.status_code == 200:
            data = r.json()
            st.session_state.token = data["token"]
            st.session_state.user = data["user"]
            st.success(f"Logged in as {data['user']['email']}")
        else:
            st.error(r.json().get("detail") if r is not None else "Login failed")
    if register_btn:
        if not name:
            st.error("Please enter name to register")
        else:
            r = api_post("/auth/register", json={"name": name, "email": email, "password": password})
            if r and r.status_code == 200:
                st.success("Registered. Now login.")
            else:
                st.error(r.json().get("detail") if r is not None else "Register failed")
else:
    st.sidebar.write(f"Logged in: {st.session_state.user.get('email')}")
    if st.sidebar.button("Logout"):
        st.session_state.token = None
        st.session_state.user = None
        st.experimental_rerun()

    st.header("Upload resume")
    uploaded = st.file_uploader("Choose resume (.pdf, .docx, .txt)", type=["pdf","doc","docx","txt"])
    if st.button("Upload") and uploaded:
        files = {"file": (uploaded.name, uploaded.getvalue())}
        r = api_post("/resume/upload", files=files)
        if r and r.status_code == 200:
            data = r.json()
            st.success(f"Uploaded. Score: {data.get('score')}")
            st.json(data.get("analysis", {}))
        else:
            st.error(r.json().get("detail") if r is not None else "Upload failed")

    st.header("Candidates")
    r = api_get("/resume/candidates")
    if r and r.status_code == 200:
        candidates = r.json()
        for c in candidates:
            st.subheader(f"{c.get('analysis', {}).get('name') or c.get('originalName')} — Score {c.get('score')}")
            st.write("Emails:", ", ".join(c.get("analysis", {}).get("emails", [])))
            st.write("Phones:", ", ".join(c.get("analysis", {}).get("phones", [])))
            st.write("Skills:", ", ".join(c.get("analysis", {}).get("skills", [])))
            st.write("---")
    else:
        st.info("No candidates yet or failed to fetch.")
